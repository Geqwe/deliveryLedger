module.exports = {
    secret: "secret"
}